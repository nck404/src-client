# hi Rua Do, Phu Pham, Hoang Long

## [check this out](https://www.youtube.com/watch?v=F48N6cOHxas)

## [Nice Flex](https://www.youtube.com/watch?v=KUqwPjXyBM0)

![1](https://media.discordapp.net/attachments/1127155311464169552/1127472775796359249/image.png?width=1108&height=559)

![2](https://media.discordapp.net/attachments/1127155311464169552/1127473739915866203/image.png) Nice Font Renderer

![3](https://media.discordapp.net/attachments/1127155311464169552/1135243045948883104/image.png?width=1166&height=560) Nice Main Menu Code, this is so clean omg!!!

![4](https://media.discordapp.net/attachments/1127155311464169552/1135240155800801401/image.png) nice sus kb code

![5](https://cdn.discordapp.com/attachments/1127155311464169552/1135239269716336690/image.png) ok

![6](https://media.discordapp.net/attachments/1127155311464169552/1135239164460277871/image.png) ok

![7](https://media.discordapp.net/attachments/1127155311464169552/1135241959884210299/image.png?width=938&height=560) I love ketamine, <3 neva lack!

![8](https://cdn.discordapp.com/attachments/1127155311464169552/1135242246044786739/image.png) nice bypass, its working btw

![9](https://cdn.discordapp.com/attachments/1127155311464169552/1135243289239502928/image.png) nice clickgui

![10](https://cdn.discordapp.com/attachments/1127155311464169552/1135243956888809612/image.png) what! nice auth

![11](https://cdn.discordapp.com/attachments/1127155311464169552/1135269887812567220/image.png)

![12](https://cdn.discordapp.com/attachments/1127155311464169552/1138842641656721408/image.png) 🤔

![13](https://media.discordapp.net/attachments/1127155311464169552/1138850569201660014/image.png) 🤔

![14](https://media.discordapp.net/attachments/988104728745484301/1138845856586551296/Discord_DkPn1zmB9r.png?width=1039&height=560)

![15](https://media.discordapp.net/attachments/1127155311464169552/1143577079154217080/image.png) WTF

## See ya
