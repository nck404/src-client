package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.KeyEvent
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "HUD", description = "Toggles visibility of the HUD.", category = ModuleCategory.RENDER, array = false)
class HUD : Module() {
    public val blackHotbarValue = BoolValue("BlackHotbar", true)
    public val inventoryParticle = BoolValue("InventoryParticle", false)
    public val fontChatValue = BoolValue("FontChat", false)
    public val chatRectValue = BoolValue("ChatRect", true)
    public val chatCombineValue = BoolValue("ChatCombine", true)
    public val chatAnimationValue = BoolValue("ChatAnimation", true)
    public val chatAnimationSpeedValue = FloatValue("Chat-AnimationSpeed", 0.1F, 0.01F, 0.1F)
    public val toggleMessageValue = BoolValue("DisplayToggleMessage", true)
    public val toggleSoundValue = BoolValue("PlayToggleSound", true)

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        LiquidBounce.moduleManager.shouldNotify = toggleMessageValue.get()
        LiquidBounce.moduleManager.shouldPlaySound = toggleSoundValue.get()
        if (mc.currentScreen is GuiHudDesigner) return
        LiquidBounce.hud.render(false)
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }

    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }

    init {
        state = true
    }
}