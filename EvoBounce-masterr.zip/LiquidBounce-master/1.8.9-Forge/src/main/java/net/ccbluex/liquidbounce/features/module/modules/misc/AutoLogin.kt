package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.minecraft.network.play.server.S02PacketChat
import net.minecraft.network.play.server.S45PacketTitle
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.TextValue

@ModuleInfo(name = "AutoLogin", description = "Automatically login into some servers for you.", category = ModuleCategory.MISC)
class AutoLogin : Module() {

	private val password = TextValue("Password", "example@01")

    @EventTarget
    fun onPacket(event: PacketEvent) {
    	if (event.packet is S45PacketTitle) {
    		val s45 = event.packet as S45PacketTitle
    		var message : String = s45.getMessage().getUnformattedText() ?: return

    		if (message.contains("/login", true)) {
    			mc.thePlayer.sendChatMessage("/login ${password.get()}")
                notifylogin("Successfully logined.")
    		}

    		if (message.contains("/register", true)) {
    			mc.thePlayer.sendChatMessage("/register ${password.get()} ${password.get()}")
                notifylogin("Successfully registered.")
    		}
    	}

    	if (event.packet is S02PacketChat) {
    		val s02 = event.packet as S02PacketChat
    		var message : String = s02.getChatComponent().getUnformattedText()

    		if (message.contains("/login", true) || message.contains("/dn", true)) { //aemine support
    			mc.thePlayer.sendChatMessage("/login ${password.get()}")
                notifylogin("Successfully logined.")
    		}

    		if (message.contains("/dk", true)) { //aemine support
    			mc.thePlayer.sendChatMessage("/dk ${password.get()}")
                notifylogin("Successfully registered.")
    		}

    		if (message.contains("/register", true)) {
    			mc.thePlayer.sendChatMessage("/register ${password.get()} ${password.get()}")
                notifylogin("Successfully registered.")
    		}
    	}
    }

    private fun notifylogin(message: String) = LiquidBounce.hud.addNotification(Notification(message, Notification.Type.SUCCESS))
    

    override val tag: String?
        get() = password.get()

}