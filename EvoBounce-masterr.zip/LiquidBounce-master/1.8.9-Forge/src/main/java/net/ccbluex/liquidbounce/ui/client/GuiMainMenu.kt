/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.ui.client

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.minecraft.client.gui.*
import net.minecraft.client.resources.I18n
import java.awt.Color

class GuiMainMenu : GuiScreen(), GuiYesNoCallback {

    override fun initGui() {
        val defaultHeight = this.height / 4 + 48

        this.buttonList.add(GuiButton(100, this.width / 2 - 55, defaultHeight + 48, 110, 20, "Alt Manager"))

        this.buttonList.add(GuiButton(1, this.width / 2 - 55, defaultHeight, 110, 20, I18n.format("menu.singleplayer")))
        this.buttonList.add(GuiButton(2, this.width / 2 - 55, defaultHeight + 24, 110, 20, I18n.format("menu.multiplayer")))
        this.buttonList.add(GuiButton(102, this.width / 2 - 55, defaultHeight + 72, 110, 20, "Background"))
        this.buttonList.add(GuiButton(0, this.width / 2 - 55, defaultHeight + 96, 110, 20, "Settings"))
        this.buttonList.add(GuiButton(4, this.width / 2 - 55, defaultHeight + 120, 110, 20, "Mods"))

        super.initGui()
    }

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        drawBackground(0)

        Gui.drawRect(width / 2 - 70, height / 4 + 35, width / 2 + 70, height / 4 + 197, Integer.MIN_VALUE)

        Fonts.fontGothic135.drawCenteredString(LiquidBounce.CLIENT_NAME, this.width / 2F, height / 8F + 20F, 4673984, true)

        Fonts.fontSFUI40.drawCenteredString("This is the final build number. (b4.x)", this.width / 2F, this.height / 4F + 150F + 48F + 10F, -1, true)
        Fonts.fontSFUI40.drawCenteredString("Thank you everyone for supporting me till this day ❤", this.width / 2F, this.height / 4F + 150F + 48F + 22F, Color(255, 0, 0, 255).rgb, true)
        super.drawScreen(mouseX, mouseY, partialTicks)
    }

    override fun actionPerformed(button: GuiButton) {
        when (button.id) {
            0 -> mc.displayGuiScreen(GuiOptions(this, mc.gameSettings))
            1 -> mc.displayGuiScreen(GuiSelectWorld(this))
            2 -> mc.displayGuiScreen(GuiMultiplayer(this))
            4 -> mc.displayGuiScreen(GuiModsMenu(this))
            100 -> mc.displayGuiScreen(GuiAltManager(this))
            102 -> mc.displayGuiScreen(GuiBackground(this))
        }
    }

    override fun keyTyped(typedChar: Char, keyCode: Int) {}
}