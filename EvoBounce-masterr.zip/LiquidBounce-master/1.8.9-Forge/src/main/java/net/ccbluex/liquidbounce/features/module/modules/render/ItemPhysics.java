package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.*;

@ModuleInfo(name = "ItemPhysics", description = "my name pwease", category = ModuleCategory.RENDER)
public class ItemPhysics extends Module
{
}
