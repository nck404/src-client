package net.mcleaks;

public interface Callback<T> {

    void done(T p0);

}
