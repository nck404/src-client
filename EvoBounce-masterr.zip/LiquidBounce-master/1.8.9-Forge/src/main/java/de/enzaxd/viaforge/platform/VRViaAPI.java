package de.enzaxd.viaforge.platform;

import com.viaversion.viaversion.ViaAPIBase;

import java.util.UUID;

public class VRViaAPI extends ViaAPIBase<UUID> {
}
