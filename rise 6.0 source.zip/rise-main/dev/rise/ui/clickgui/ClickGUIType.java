package dev.rise.ui.clickgui;

public interface ClickGUIType {
}
