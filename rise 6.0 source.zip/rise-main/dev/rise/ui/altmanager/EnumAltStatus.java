package dev.rise.ui.altmanager;

public enum EnumAltStatus {
    PREMIUM,
    CRACKED,
    FAILED,
    NOT_LOGGED_IN
}
