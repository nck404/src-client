package dev.rise.dorttesting;

public class BedrockSupportBase {

    public BedrockSupportBase() {

    }
}
