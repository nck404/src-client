package dev.rise.event.impl.other;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Button {
    boolean button;
    double offset;
}
