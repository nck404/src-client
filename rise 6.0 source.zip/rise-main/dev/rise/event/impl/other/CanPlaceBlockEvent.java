package dev.rise.event.impl.other;

import dev.rise.event.api.Event;

public final class CanPlaceBlockEvent extends Event {
}
