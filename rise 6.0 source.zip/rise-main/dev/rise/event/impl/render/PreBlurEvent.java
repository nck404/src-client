package dev.rise.event.impl.render;

import dev.rise.event.api.Event;

public final class PreBlurEvent extends Event {
}
