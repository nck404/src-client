package dev.rise.event.impl.motion;

import dev.rise.event.api.Event;

public final class PostMotionEvent extends Event {
}
