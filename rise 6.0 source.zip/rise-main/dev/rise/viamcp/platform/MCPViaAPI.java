package dev.rise.viamcp.platform;

import com.viaversion.viaversion.ViaAPIBase;

import java.util.UUID;

public class MCPViaAPI extends ViaAPIBase<UUID> {
}
