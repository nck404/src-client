package dev.rise.module.impl.movement;

import dev.rise.module.Module;
import dev.rise.module.api.ModuleInfo;
import dev.rise.module.enums.Category;

@ModuleInfo(name = "No0.03", description = "Removes a value which causes AntiCheats to falsely flag you", category = Category.MOVEMENT)
public final class No003 extends Module {
}
