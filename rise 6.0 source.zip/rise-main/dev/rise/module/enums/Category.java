package dev.rise.module.enums;

public enum Category {
    COMBAT,
    MOVEMENT,
    PLAYER,
    RENDER,
    LEGIT,
    OTHER,
    SCRIPTS,
//    STORE,
    CONFIGS,
    INFO;

    public int moduleIndex;
}