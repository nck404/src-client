package dev.rise.util.pathfinding.alan;

public enum Mode {
    NORMAL,
    LEGIT
}
