package dev.rise.util.pathfinding.alan;

public enum Prioritise {
    FASTEST_PATH,
    LEAST_POINTS
}
