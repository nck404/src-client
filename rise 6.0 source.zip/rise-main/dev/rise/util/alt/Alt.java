package dev.rise.util.alt;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class Alt {
    private String email, password;
}
