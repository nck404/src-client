package dev.rise.util.misc.socialcreditscore;

public enum EnumCrimes {
    ATTACK, ATTACK_WITH_WEAPON
}
