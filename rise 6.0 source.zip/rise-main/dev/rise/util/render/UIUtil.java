package dev.rise.util.render;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.UtilityClass;

@Getter
@Setter
@UtilityClass
public class UIUtil {
    public float logoPosition;
}
