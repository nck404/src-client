package dev.rise.config.online;

public enum ConfigState {
    NONE,
    LOADING,
    FAILED,
    DONE
}
