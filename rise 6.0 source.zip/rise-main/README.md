latest rise source code (thanks to fatality)
